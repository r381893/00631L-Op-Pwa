# 00631L 避險戰情室

一個跨平台（桌面版 + 手機 PWA）的 **00631L 槓桿 ETF** 避險策略管理系統。

## 功能特色

- 📊 **即時損益追蹤** - 監控 00631L 持股的損益變化
- 🛡️ **選擇權避險** - 支援複試單策略（Buy Put + Sell Call 等）
- 📈 **期貨避險** - 微台、小台期貨部位管理
- 📱 **PWA 支援** - 可安裝到手機主畫面，提供 App-like 體驗
- 💾 **自動儲存** - LocalStorage 持久化（可升級為 Firebase）

## 快速開始

### 前端開發

```bash
# 安裝依賴
npm install

# 啟動開發伺服器
npm run dev

# 建置生產版本
npm run build
```

### 後端 API（可選）

```bash
cd server
npm install
npm run dev
```

## 技術架構

- **前端**: Vite + React
- **圖表**: Recharts
- **樣式**: Vanilla CSS (深色主題)
- **PWA**: vite-plugin-pwa
- **後端**: Express + yahoo-finance2
- **資料庫**: LocalStorage / Firebase (可選)

## 部署

- **前端**: GitHub Pages 或 Vercel
- **後端**: Render.com

## 授權

MIT License
